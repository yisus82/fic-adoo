package es.udc.mashup.ui.server.rss;

public interface RootElement extends Element {

}
