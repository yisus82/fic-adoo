package es.udc.mashup.ui.client.search;

public class RevenueTypeAsStringConstants {

	private RevenueTypeAsStringConstants() {
	}

	public final static String HIGH = "H";

	public final static String MEDIUM = "M";

	public final static String LOW = "L";

}
