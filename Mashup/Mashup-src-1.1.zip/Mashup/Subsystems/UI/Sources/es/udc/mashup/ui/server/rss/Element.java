package es.udc.mashup.ui.server.rss;

public interface Element {

	public String toString();

}
