package es.udc.mashup.ui.server.rss.exception;

public class RSSException extends Exception {

	public RSSException(String message) {
		super(message);
	}

}
